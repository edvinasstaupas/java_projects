package lt.staupasedvinas;

public class BadInputException extends Exception {
    BadInputException() {
        super("Bad input");
    }
}
